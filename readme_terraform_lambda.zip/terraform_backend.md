Absolutely! Here’s a comprehensive **README** draft based on everything we discussed. It explains the issues with GitHub Actions, missing Terraform state, and how to fix and properly manage remote backends and S3 resources.

---

# Terraform GitHub Actions Setup with Remote Backend

This README explains how to properly manage Terraform resources using **GitHub Actions** with a **remote S3 backend**, avoiding duplicate resource creation and enabling safe destroy operations.

---

## **1. Problem Overview**

When using Terraform in GitHub Actions without a remote backend:

* The Terraform state is stored **locally in the runner** (`.terraform/terraform.tfstate`).
* GitHub Actions runners are ephemeral; the state file is **deleted after the job finishes**.
* Terraform loses track of previously created resources and **recreates them every run** (e.g., multiple S3 buckets).
* Destroying resources becomes impossible because Terraform has **no record of them**.

---

## **2. Recommended Solution**

1. Use a **remote S3 backend** for Terraform state.
2. Use **fixed resource names** for AWS resources (like S3 buckets) to avoid duplication.
3. Optionally, use **Terraform workspaces** for multiple environments (`prod`, `staging`).

---

## **3. Step 1 — Create S3 Backend & DynamoDB Table**

Before running Terraform, create the backend bucket and a DynamoDB table for state locking:

```bash
# Create S3 bucket for Terraform state
aws s3api create-bucket \
  --bucket gomsc2025-terraform-state-bucket \
  --region eu-central-1 \
  --create-bucket-configuration LocationConstraint=eu-central-1

# Enable versioning on the bucket (recommended)
aws s3api put-bucket-versioning \
  --bucket gomsc2025-terraform-state-bucket \
  --versioning-configuration Status=Enabled

# Create DynamoDB table for state locking
aws dynamodb create-table \
  --table-name terraform-locks \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST
```

> Ensure the AWS account or role used in GitHub Actions has **full access to this bucket and DynamoDB table**.

---

## **4. Step 2 — Configure Terraform Backend**

In your Terraform configuration (`infra/main.tf` or equivalent):

```hcl
terraform {
  backend "s3" {
    bucket         = "gomsc2025-terraform-state-bucket"
    key            = "prod/terraform.tfstate"
    region         = "eu-central-1"
    dynamodb_table = "terraform-locks"
  }
}
```

* `bucket`: Name of the S3 bucket storing Terraform state.
* `key`: Path of the state file inside the bucket.
* `dynamodb_table`: Optional, used for state locking.
* `region`: Region of the S3 bucket.

---

## **5. Step 3 — GitHub Actions Workflow**

Example workflow:

```yaml
name: Terraform Deploy

on:
  push:
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3

      - name: Configure AWS Credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::<ACCOUNT_ID>:role/GitHubActionsTerraformRole
          aws-region: eu-central-1

      - name: Terraform Init
        run: |
          cd infra
          terraform init -reconfigure

      - name: Terraform Apply
        run: |
          cd infra
          terraform apply -auto-approve -var-file=../infra/envs/public.tfvars
```

> `-reconfigure` ensures Terraform connects to the remote backend even if local state exists.

---

## **6. Step 4 — Use Fixed Resource Names**

Example for S3 bucket:

```hcl
resource "aws_s3_bucket" "my_bucket" {
  bucket = "my-fixed-bucket-name" # fixed name avoids duplicates
  acl    = "private"

  versioning {
    enabled = true
  }
}
```

* Avoid dynamic/random bucket names in CI, as this creates new buckets every run.

---

## **7. Step 5 — Optional: Workspaces for Multiple Environments**

```bash
terraform workspace new prod || terraform workspace select prod
```

* Each workspace has its **own state file** in the same S3 bucket.
* Useful for `prod`, `staging`, `dev` environments.

---

## **8. Step 6 — Locally Destroy Resources**

1. Ensure local Terraform uses the **same backend configuration**:

```bash
terraform init -reconfigure
terraform state list
terraform destroy -auto-approve -var-file=../infra/envs/public.tfvars
```

2. Local destroy now works because Terraform uses the **same S3 state as CI**.

---

## **9. Step 7 — Handling Orphaned Resources**

If previous GitHub Actions runs created resources without a remote backend:

1. Identify them manually in AWS (S3 buckets, IAM roles, etc.).
2. Either:

   * Import them into Terraform:

     ```bash
     terraform import aws_s3_bucket.my_bucket my-fixed-bucket-name
     ```

   * Or delete them manually in the AWS console.

---

## **10. Key Takeaways**

* Always use a **remote backend** for CI Terraform runs.
* Avoid dynamic resource names in CI workflows.
* Use **DynamoDB locking** to prevent concurrent modifications.
* Use **fixed backend configuration** to ensure CI and local Terraform share the same state.
* Orphaned resources need to be manually managed if Terraform never stored state.

---

This README now serves as a **guide for GitHub Actions + Terraform + S3 backend**, preventing multiple resource creation and enabling safe `destroy` operations.

---

If you want, I can also **write a ready-to-use Terraform + GitHub Actions template repo** that implements all of this, fully idempotent for S3 buckets and backend state.

Do you want me to do that?
