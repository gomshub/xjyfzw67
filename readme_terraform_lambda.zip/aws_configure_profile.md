Yes! You can configure **multiple AWS credentials** locally using **profiles**, which is very useful if you have more than one IAM user or AWS account. Here’s how to do it:

---

## **Step 1: Create a Named Profile**

Run this command in your terminal:

```bash
aws configure --profile terraform-test
```

You’ll be prompted to enter:

```
AWS Access Key ID [None]: <your-access-key-id>
AWS Secret Access Key [None]: <your-secret-access-key>
Default region name [None]: eu-central-1
Default output format [None]: json
```

* `--profile terraform-test` → This is the **profile name**. You can choose any name.
* The credentials will be stored in `~/.aws/credentials` under `[terraform-test]`.

---

## **Step 2: Use the Profile in Terraform**

In your Terraform `provider` block, specify the profile:

```hcl
provider "aws" {
  region  = "eu-central-1"
  profile = "terraform-test"
}
```

* Terraform will use the credentials from that profile.

---

## **Step 3: Use the Profile with AWS CLI**

```bash
aws s3 ls --profile terraform-test
```

* Any AWS CLI command can specify the profile with `--profile <name>`.

---

## **Step 4: Set a Default Profile (Optional)**

If you want to temporarily use this profile as default in your terminal session:

```bash
export AWS_PROFILE=terraform-test
```

* After that, `aws s3 ls` will automatically use `terraform-test` without `--profile`.
* Works for Terraform too.

---

✅ **Summary**

* Use `aws configure --profile <name>` to create multiple credentials.
* Specify the profile in Terraform or AWS CLI with `profile = "<name>"` or `--profile`.
* Use `AWS_PROFILE` environment variable to make a profile the default temporarily.

---

If you want, I can write a **ready-to-use Terraform example** that uses a named profile for safe local testing.

Do you want me to do that?
