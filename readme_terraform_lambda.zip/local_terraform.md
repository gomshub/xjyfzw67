5️⃣ Instructions for Local Development

Install Terraform (>=1.5.0) and AWS CLI.

Configure AWS credentials (access to backend bucket + DynamoDB):

aws configure
# or assume the same role as GitHub Actions
aws sts assume-role \
  --role-arn arn:aws:iam::<ACCOUNT_ID>:role/GitHubActionsTerraformRole \
  --role-session-name terraform-local
export AWS_ACCESS_KEY_ID=<AccessKeyId>
export AWS_SECRET_ACCESS_KEY=<SecretAccessKey>
export AWS_SESSION_TOKEN=<SessionToken>


Initialize Terraform backend locally:

cd infra
terraform init -reconfigure
terraform workspace new prod || terraform workspace select prod


Apply or destroy resources locally:

terraform apply -auto-approve -var-file=envs/public.tfvars
terraform destroy -auto-approve -var-file=envs/public.tfvars