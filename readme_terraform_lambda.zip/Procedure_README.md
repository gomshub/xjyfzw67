🧾 README.md
# AWS Lambda → Snowflake → S3 Terraform Deployment

This repository automates deploying an AWS Lambda function that queries Snowflake and writes results to S3.
It supports **two modes**:

- `public` — uses Snowflake public endpoint (free/local testing)
- `private` — uses AWS PrivateLink + custom DNS (secure enterprise setup)

---

## 🧩 Project Structure



infra/
├─ main.tf
├─ variables.tf
├─ outputs.tf
├─ modules/
│ ├─ lambda/
│ ├─ s3/
│ ├─ vpc/
└─ envs/
├─ public.tfvars
└─ private.tfvars
.github/
└─ workflows/
├─ deploy-staging.yml
├─ deploy-prod.yml
└─ destroy.yml
automate.ps1
README.md


---

## 🔐 Secure Authentication

### ✅ GitHub → AWS (OIDC) — No Secrets Stored

Use **OpenID Connect (OIDC)** to let GitHub Actions assume a temporary AWS IAM role.

1. In AWS Console → IAM → Roles → Create role  
   - Type: `Web identity`  
   - Provider: `https://token.actions.githubusercontent.com`  
   - Audience: `sts.amazonaws.com`
2. Paste the following trust policy (replace `<ACCOUNT_ID>`, `<ORG>`, `<REPO>`):

   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Principal": {
           "Federated": "arn:aws:iam::<ACCOUNT_ID>:oidc-provider/token.actions.githubusercontent.com"
         },
         "Action": "sts:AssumeRoleWithWebIdentity",
         "Condition": {
           "StringEquals": {
             "token.actions.githubusercontent.com:aud": "sts.amazonaws.com",
             "token.actions.githubusercontent.com:sub": "repo:<ORG>/<REPO>:ref:refs/heads/main"
           }
         }
       }
     ]
   }


Attach these managed policies temporarily (reduce later):

AWSLambda_FullAccess

AmazonS3FullAccess

SecretsManagerReadWrite

AmazonVPCFullAccess

3 more policies added:
{
	"Version": "2012-10-17",
	"Statement": [
		{
			"Sid": "AllowCreateLambdaRoles",
			"Effect": "Allow",
			"Action": [
				"iam:CreateRole",
				"iam:TagRole",
				"iam:AttachRolePolicy",
				"iam:PutRolePolicy",
				"iam:GetRole",
				"iam:DeleteRole",
				"iam:DeleteRolePolicy",
				"iam:DetachRolePolicy"
			],
			"Resource": "arn:aws:iam::230082279380:role/public-lambda-role"
		}
	]
}

{
	"Version": "2012-10-17",
	"Statement": [
		{
			"Sid": "DynamodbAccess",
			"Effect": "Allow",
			"Action": [
				"dynamodb:PutItem",
				"dynamodb:GetItem",
				"dynamodb:DeleteItem",
				"dynamodb:UpdateItem",
				"dynamodb:Scan"
			],
			"Resource": "arn:aws:dynamodb:eu-central-1:230082279380:table/terraform-locks"
		}
	]
}

{
	"Version": "2012-10-17",
	"Statement": [
		{
			"Sid": "S3StateBackend",
			"Effect": "Allow",
			"Action": [
				"s3:ListBucket",
				"s3:GetObject",
				"s3:PutObject",
				"s3:DeleteObject",
				"s3:GetBucketVersioning",
				"s3:PutBucketVersioning"
			],
			"Resource": [
				"arn:aws:s3:::gomsc2025-terraform-state-bucket",
				"arn:aws:s3:::gomsc2025-terraform-state-bucket/*"
			]
		}
	]
}


Name the role: GitHubActionsTerraformRole

🧰 Snowflake Secret Setup

In AWS Console → Secrets Manager → “Store a new secret” → Other type of secret

{
  "username": "CI_USER",
  "password": "StrongPassword123!",
  "account": "xy12345.eu-central-1",
  "warehouse": "COMPUTE_WH",
  "database": "TEST_DB",
  "schema": "PUBLIC"
}


Secret name → snowflake/ci_user

Then note the ARN for Terraform:

snowflake_secret_arn = "arn:aws:secretsmanager:eu-central-1:123456789012:secret:snowflake/ci_user"

🌐 tfvars Configuration

infra/envs/public.tfvars

environment = "public"
enable_privatelink = false
snowflake_secret_arn = "arn:aws:secretsmanager:eu-central-1:xxxx:secret:snowflake/ci_user"


infra/envs/private.tfvars

environment = "private"
enable_privatelink = true
snowflake_secret_arn = "arn:aws:secretsmanager:eu-central-1:xxxx:secret:snowflake/ci_user"

🚀 Deployment
Staging (auto)

Runs automatically on push to main branch:

.github/workflows/deploy-staging.yml

Production (manual)

Triggered manually from GitHub Actions:

.github/workflows/deploy-prod.yml

Destroy (manual cleanup)
terraform destroy -auto-approve -var-file=../envs/public.tfvars


or trigger GitHub Action:
🧹 “Destroy AWS Resources”.

🧩 Cost Overview
Component	Est. Cost/month
Interface VPC Endpoint	~$7
Lambda + Logs + Secrets	~$1
S3 + Requests	<$0.10
Snowflake XSMALL (1 hr use)	~$2
Total (test env)	~$9–10/month

To stay under $5, destroy PrivateLink after testing.

🧑‍💻 Local Testing

If you use AWS SSO / Identity Center, log in first:

aws sso login --profile my-sso
export AWS_PROFILE=my-sso
cd infra
terraform apply -var-file=../envs/public.tfvars

🧠 Key Tips

Use terraform destroy after every test.

Switch environments via -var-file.

PrivateLink costs money even idle.

Never store AWS or Snowflake creds in GitHub secrets.

Keep warehouse AUTO_SUSPEND = 60 in Snowflake.