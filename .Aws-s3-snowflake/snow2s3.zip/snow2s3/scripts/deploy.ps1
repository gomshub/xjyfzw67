﻿param(
  [string]$Environment = 'staging'
)

# Load common env
Get-Content 'config/.env.common' | ForEach-Object {
  if ($_ -match '^(.*?)=(.*)$') { Set-Item -Path Env:$($matches[1]) -Value $matches[2] }
}
# Load env specific
Get-Content "config/.env.$Environment" | ForEach-Object {
  if ($_ -match '^(.*?)=(.*)$') { Set-Item -Path Env:$($matches[1]) -Value $matches[2] }
}

# Build & push Docker image (requires aws cli and docker logged in)
$version = (Get-Content 'lambda/version.txt' -Raw).Trim()
Write-Host "Building image version $version..."

docker build -t $Env:ECR_REPO:$version ./lambda

# Ensure ECR repository exists (create it if not)
$repo = "$Env:AWS_ACCOUNT_ID.dkr.ecr.$Env:AWS_REGION.amazonaws.com/$Env:ECR_REPO"
Write-Host "Ensuring ECR repo: $repo"
try {
  aws ecr describe-repositories --repository-names $Env:ECR_REPO --region $Env:AWS_REGION | Out-Null
} catch {
  Write-Host 'ECR repo not found — creating...'
  aws ecr create-repository --repository-name $Env:ECR_REPO --region $Env:AWS_REGION | Out-Null
}

# push
aws ecr get-login-password --region $Env:AWS_REGION | docker login --username AWS --password-stdin "$Env:AWS_ACCOUNT_ID.dkr.ecr.$Env:AWS_REGION.amazonaws.com"
docker tag $Env:ECR_REPO:$version "$Env:AWS_ACCOUNT_ID.dkr.ecr.$Env:AWS_REGION.amazonaws.com/$Env:ECR_REPO:$version"
docker push "$Env:AWS_ACCOUNT_ID.dkr.ecr.$Env:AWS_REGION.amazonaws.com/$Env:ECR_REPO:$version"

# Terraform apply
Write-Host 'Running terraform...'
cd terraform
terraform init
terraform apply -auto-approve -var-file="environments/$Environment.tfvars"

Write-Host 'Done.'