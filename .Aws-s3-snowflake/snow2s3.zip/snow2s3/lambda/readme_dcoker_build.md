🧩 1️⃣️  Dockerfile Args
    • Uses ARG and ENV for flexibility. You can override LAMBDA_TASK_ROOT if needed.
    • Default remains /var/task (the AWS standard).
    • Keeps the handler consistent for local testing and AWS deployment.




🧩 ️2️⃣ Local Docker Build (Windows or Linux)

# To test locally:
`docker build -t snow2s3-lambda:latest --build-arg LAMBDA_TASK_ROOT_ARG=/var/task .`
Run it locally with AWS Lambda emulator syntax:
`docker run -p 9000:8080 snow2s3-lambda:latest`
Then invoke locally:
`curl -XPOST "http://localhost:9000/2015-03-31/functions/function/invocations" -d '{}'`


🧩 4️⃣️⃣ GitHub Actions Build (With Env Args)

Update your Build & Push step in the workflow:
- name: Build and Push Lambda Docker Image
  run: |
    IMAGE_URI="${{ secrets.AWS_ACCOUNT_ID }}.dkr.ecr.${{ env.AWS_REGION }}.amazonaws.com/${{ env.ECR_REPO }}:${{ env.VERSION }}"
    echo "Building and pushing image: $IMAGE_URI"
docker build \
      --build-arg LAMBDA_TASK_ROOT_ARG=/var/task \
      -t $IMAGE_URI ./lambda
docker push $IMAGE_URI
echo "IMAGE_URI=$IMAGE_URI" >> $GITHUB_ENV
    echo "✅ Lambda image pushed successfully: $IMAGE_URI"



🧩 5️⃣️⃣ For Terraform (if used in Lambda resource)

If your Lambda function resource in Terraform needs this image:
resource "aws_lambda_function" "snow2s3" {
  function_name = "snow2s3"
  package_type  = "Image"
  image_uri     = var.image_uri  # Passed dynamically from pipeline
  role          = aws_iam_role.lambda_exec.arn
  environment {
    variables = {
      ENVIRONMENT = var.environment
      PROJECT     = "snow2s3"
    }
  }
}
Then your workflow can append to Terraform command:
terraform apply -auto-approve \
  -var-file="environments/${{ env.ENV }}.tfvars" \
  -var="image_uri=${{ env.IMAGE_URI }}"



✅ Summary
Component	Purpose	Example
ARG LAMBDA_TASK_ROOT_ARG	Build-time argument	/var/task
ENV LAMBDA_TASK_ROOT	Runtime env var	/var/task
GitHub build arg	Pass to Docker build	--build-arg LAMBDA_TASK_ROOT_ARG=/var/task
Terraform var	Update Lambda image	-var="image_uri=${{ env.IMAGE_URI }}"
