﻿import os
import io
import csv
import json
import boto3
import yaml
import logging
import snowflake.connector
from datetime import datetime

# Logger setup
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS clients
s3 = boto3.client('s3')
ssm = boto3.client('ssm')

# Environment variables
OUTPUT_S3_BUCKET = os.getenv('OUTPUT_S3_BUCKET')
SSM_SF_PARAM = os.getenv('SSM_SF_PARAM')
SNOWFLAKE_PRIVATELINK_ENABLED = os.getenv('SNOWFLAKE_PRIVATELINK_ENABLED', 'false').lower() == 'true'
SNOWFLAKE_PRIVATELINK_ENDPOINT = os.getenv('SNOWFLAKE_PRIVATELINK_ENDPOINT')

# Use LAMBDA_TASK_ROOT if set, otherwise /var/task; keep backward compatibility with /app
TASK_ROOT = os.getenv('LAMBDA_TASK_ROOT', '/var/task')
LOCAL_CONFIG_PATH = os.path.join(TASK_ROOT, 'config', 'queries.yml')

def get_config():
    """Load SQL queries from local YAML config if present"""
    try:
        if os.path.exists(LOCAL_CONFIG_PATH):
            logger.info("Loading queries from %s", LOCAL_CONFIG_PATH)
            with open(LOCAL_CONFIG_PATH, 'rb') as f:
                cfg = yaml.safe_load(f) or {}
                return cfg
        else:
            logger.info("No local queries file found at %s", LOCAL_CONFIG_PATH)
    except Exception as e:
        logger.exception("Failed to load config file: %s", e)
    return {'queries': {}}

def get_snowflake_creds():
    """Fetch Snowflake credentials from SSM Parameter Store"""
    logger.info("Fetching Snowflake creds from SSM: %s", SSM_SF_PARAM)
    resp = ssm.get_parameter(Name=SSM_SF_PARAM, WithDecryption=True)
    return json.loads(resp['Parameter']['Value'])

def run_query(sql, prefix='result'):
    logger.info("Starting run_query for prefix=%s", prefix)
    creds = get_snowflake_creds()
    logger.info("Connecting to Snowflake account=%s user=%s", creds.get('account'), creds.get('user'))
    ctx = snowflake.connector.connect(
        user=creds.get('user'),
        password=creds.get('password'),
        account=creds.get('account'),
        warehouse=creds.get('warehouse'),
        database=creds.get('database'),
        schema=creds.get('schema'),
        role=creds.get('role')
    )
    cs = ctx.cursor()
    try:
        logger.info("Executing SQL: %s", sql if len(sql) < 200 else sql[:200] + "...")
        cs.execute(sql)
        cols = [c[0] for c in cs.description] if cs.description else []
        rows = cs.fetchall()
        logger.info("Query returned %d rows", len(rows))
        buf = io.StringIO()
        writer = csv.writer(buf)
        if cols:
            writer.writerow(cols)
        writer.writerows(rows)
        data = buf.getvalue().encode('utf-8')
        datepart = datetime.utcnow().strftime('%Y-%m-%d')
        key = f"{prefix}/{datepart}/{prefix}_{datetime.utcnow().strftime('%H%M%S')}.csv"
        logger.info("Uploading to s3://%s/%s", OUTPUT_S3_BUCKET, key)
        s3.put_object(Bucket=OUTPUT_S3_BUCKET, Key=key, Body=data)
        logger.info("Upload complete")
        return {'rows': len(rows), 's3_key': key}
    finally:
        try:
            cs.close()
            ctx.close()
        except Exception:
            pass

def lambda_handler(event, context):
    logger.info("Lambda invoked, event keys: %s", list(event.keys()) if isinstance(event, dict) else str(event))
    # Prioritize event-provided queries (for manual testing)
    cfg = get_config()
    queries = event.get('queries') if isinstance(event, dict) and event.get('queries') else cfg.get('queries', {})
    logger.info("Queries to run: %s", list(queries.keys()))
    results = {}
    for name, sql in queries.items():
        try:
            logger.info('Running query %s', name)
            results[name] = run_query(sql, prefix=name)
        except Exception as exc:
            logger.exception("Error running query %s: %s", name, exc)
            results[name] = {'error': str(exc)}
    logger.info("Lambda completed. Results: %s", results)
    return {'status': 'ok', 'results': results}
