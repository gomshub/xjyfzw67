#!/usr/bin/env bash
set -e

# -------------------------
# Simulate GitHub Actions
# -------------------------

# 1️⃣ Set ENV (default to staging if not provided)
ENV="${1:-staging}"
echo "ENV=$ENV"

# 2️⃣ Define GitHub environment file simulation
GITHUB_ENV="./.github_env_sim"
> "$GITHUB_ENV"  # clear previous

# 3️⃣ Function to load .env file
load_env_file() {
  local FILE="$1"
  if [ -f "$FILE" ]; then
    echo "Loading $FILE..."
    while IFS= read -r line || [ -n "$line" ]; do
      # Skip comments and empty lines
      [[ "$line" =~ ^\s*# ]] && continue
      [[ -z "$line" ]] && continue
      # Trim whitespace
      line="$(echo "$line" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
      # Only process lines with '='
      if [[ "$line" == *"="* ]]; then
        key="${line%%=*}"
        value="${line#*=}"
        # Remove quotes
        value="${value%\"}"
        value="${value#\"}"
        # Export to current shell
        export "$key=$value"
        # Write to simulated GitHub environment file
        echo "$key=$value" >> "$GITHUB_ENV"
      fi
    done < "$FILE"
  fi
}

# 4️⃣ Load common and env-specific files
load_env_file "config/.env.common"
load_env_file "config/.env.$ENV"

echo "✅ Loaded environment variables from .env.common and .env.$ENV"

# 5️⃣ Print all loaded variables for verification
echo "--- Loaded variables ---"
cat "$GITHUB_ENV"
echo "------------------------"
