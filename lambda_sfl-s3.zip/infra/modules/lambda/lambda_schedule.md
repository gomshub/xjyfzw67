Perfect! Since everything is already deployed, here’s a **Terraform snippet** to schedule your existing Lambda to run **once a month** using EventBridge (CloudWatch Events):

---

```hcl
# Schedule rule: run once a month on the 1st day at 00:00 UTC
resource "aws_cloudwatch_event_rule" "lambda_schedule_monthly" {
  name                = "${var.environment}-query-snowflake-monthly"
  schedule_expression = "cron(0 0 1 * ? *)"  # 1st day of every month at 00:00 UTC
}

# Lambda target
resource "aws_cloudwatch_event_target" "lambda_target_monthly" {
  rule      = aws_cloudwatch_event_rule.lambda_schedule_monthly.name
  target_id = "QuerySnowflakeLambdaMonthly"
  arn       = aws_lambda_function.query_snowflake.arn
}

# Permission for EventBridge to invoke Lambda
resource "aws_lambda_permission" "allow_eventbridge_monthly" {
  statement_id  = "AllowExecutionFromEventBridgeMonthly"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.query_snowflake.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.lambda_schedule_monthly.arn
}
```

---

### **Explanation**

* `cron(0 0 1 * ? *)` → Runs **once per month** on the **1st day** at **00:00 UTC**.
* `aws_cloudwatch_event_target` → Tells EventBridge which Lambda to invoke.
* `aws_lambda_permission` → Grants EventBridge permission to execute the Lambda.

---

### **Optional Notes**

* Adjust the time by changing the **hour/minute** in the cron: `cron(Min Hour Day Month Day-of-week Year)`.
* Terraform will **only create the schedule**, it won’t modify your Lambda code.

---

If you want, I can also give a **ready-to-deploy full snippet** that includes the Lambda, IAM role, S3 bucket, and monthly schedule in one module so everything is fully automated.

Do you want me to do that?
