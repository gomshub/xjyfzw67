import os
import json
import boto3
import snowflake.connector

def lambda_handler(event, context):
    # Get Snowflake credentials from Secrets Manager
    secret_arn = os.environ['SNOWFLAKE_SECRET_ARN']
    secrets_client = boto3.client('secretsmanager')
    secret_value = secrets_client.get_secret_value(SecretId=secret_arn)
    secret_dict = json.loads(secret_value['SecretString'])

    sf_user = secret_dict['username']
    sf_password = secret_dict['password']
    sf_account = secret_dict['account']
    sf_warehouse = secret_dict['warehouse']
    sf_database = secret_dict['database']
    sf_schema = secret_dict['schema']

    # Connect to Snowflake
    ctx = snowflake.connector.connect(
        user=sf_user,
        password=sf_password,
        account=sf_account,
        warehouse=sf_warehouse,
        database=sf_database,
        schema=sf_schema
    )

    cs = ctx.cursor()
    try:
        cs.execute("SELECT * FROM your_table LIMIT 10")  # Replace with your query
        rows = cs.fetchall()
        data = [list(row) for row in rows]
    finally:
        cs.close()
        ctx.close()

    # Push results to S3
    s3 = boto3.client('s3')
    s3.put_object(
        Bucket=os.environ['OUTPUT_BUCKET'],
        Key='snowflake_data.json',
        Body=json.dumps(data)
    )

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Data pushed to S3", "row_count": len(data)})
    }
