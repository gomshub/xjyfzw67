Absolutely! Let’s create a **clean Docker-based workflow** to build a **Linux-compatible Lambda package** for Python 3.11 including `snowflake-connector-python`. I’ll provide a **Dockerfile, README, and step-by-step packaging instructions**.

---

# **1️⃣ Dockerfile**

Create `Dockerfile` in your `modules/lambda` folder:

```dockerfile
# Use AWS Lambda Python 3.11 base image
FROM public.ecr.aws/lambda/python:3.11

# Set working directory inside container
WORKDIR /var/task

# Copy project files into container
COPY . .

# Install Python dependencies into lambda_package
RUN mkdir -p lambda_package && \
    cp lambda_functions.py lambda_package/ && \
    pip install --upgrade --target=lambda_package -r requirements.txt

# Zip contents
RUN cd lambda_package && zip -r ../lambda.zip . && cd ..

# Lambda.zip will be in /var/task/lambda.zip
CMD ["echo", "Lambda package ready: lambda.zip"]
```

---

# **2️⃣ requirements.txt**

Example file:

```
snowflake-connector-python
boto3
```

* Add any other dependencies here.
* Keep it simple and compatible with Lambda Linux runtime.

---

# **3️⃣ README.md**

```markdown
# AWS Lambda Packaging with Docker (Python 3.11)

This guide explains how to package your Python Lambda with dependencies (including Snowflake connector)
in a **Linux-compatible environment** using Docker.

---

## **1. Folder Structure**

```

modules/lambda/
├─ lambda_functions.py      # Lambda handler
├─ requirements.txt         # Python dependencies
├─ Dockerfile               # Build environment
└─ lambda.zip (generated)   # Deployment package

````

---

## **2. Build Lambda Package using Docker**

1. Navigate to the lambda folder:

```bash
cd modules/lambda
````

2. Build the Docker image:

```bash
docker build -t lambda-build .
```

3. Run the Docker container:

```bash
docker run --rm -v "$PWD":/var/task lambda-build
```

* After the container finishes, `lambda.zip` will appear in the `modules/lambda` folder.
* The ZIP contains:

  * `lambda_functions.py` at the root
  * All Python dependencies installed in Linux-compatible format

---

## **3. Deploy with Terraform**

Update your Terraform Lambda resource:

```hcl
resource "aws_lambda_function" "query_snowflake" {
  filename      = "${path.module}/lambda.zip"
  function_name = "${var.environment}-query-snowflake"
  runtime       = "python3.11"
  handler       = "lambda_functions.lambda_handler"
  role          = aws_iam_role.lambda_exec.arn
}
```

* `handler` = `<PYTHON_FILENAME_WITHOUT_.py>.<FUNCTION_NAME>`

---

## **4. Notes**

* **Always build the ZIP in Linux** for Lambda to avoid errors like:

```
module 'os' has no attribute 'add_dll_directory'
```

* `.gitignore` should include:

```
lambda_package/
lambda.zip
```

* Re-run Docker build **whenever you update your handler or requirements**.

````

---

# **4️⃣ Packaging Steps Summary**

1. Make sure `lambda_functions.py` and `requirements.txt` are ready.  
2. Build the Docker image:

```bash
cd modules/lambda
docker build -t lambda-build .
````

3. Run the Docker container to generate `lambda.zip`:

```bash
docker run --rm -v "$PWD":/var/task lambda-build
```

4. Inspect ZIP (optional):

```bash
unzip -l lambda.zip
```

* You should see `lambda_functions.py` at the root and dependencies.

5. Deploy via Terraform:

```bash
terraform apply -target=module.lambda.aws_lambda_function.query_snowflake
```

---

✅ **This ensures:**

* Snowflake connector is **Linux-compatible**
* Handler is **at root of ZIP**
* Terraform deploys the Lambda without import errors

---

I can also create a **single script that automates Docker build + Terraform deploy**, so you can do **one command** to rebuild and redeploy your Lambda.

Do you want me to do that?
